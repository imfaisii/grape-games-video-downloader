import express from 'express'
import bodyParser from 'body-parser'
import puppeteer from 'puppeteer';

const args = process.argv;
console.log(args);
// var app = express();

// // parse application/x-www-form-urlencoded
// app.use(bodyParser.urlencoded({ extended: false }))

// // parse application/json
// app.use(bodyParser.json())

// var success = {
//   bool: false,
//   status: "success",
//   code: 200,
//   message: "Action successful",
//   data: {}
// };

// var error = {
//   bool: false,
//   status: "error",
//   code: 400,
//   message: "Action failed",
//   data: {}
// }

// function setSuccess(data) {
//   success = {
//     bool: true,
//     status: "success",
//     code: 200,
//     message: "Action successful.",
//     data: data
//   };

//   error.bool = false
// }

// function setError(data) {
//   error = {
//     bool: true,
//     status: "error",
//     code: 400,
//     message: "Action failed.",
//     data: data
//   };

//   success.bool = false
// }

// async function scrapFacebook(page, url) {

//   await page.goto(url, { waitUntil: 'load' })

//   let content = await page.content()

//   if (content.includes('playable_url_dash')) {
//     let json = content.split('"playable_url_dash":').pop().split(',"spherical_video_fallback_urls')[0];

//     setSuccess(JSON.parse(`{"playable_url_dash":${json}}`))

//   } else setError('Video url cannot be fetched or invalid url.')
// }

// async function scrapInstagram(page, url) {
//   await page.goto(url); // wait until page load

//   const [response] = await Promise.all([
//     page.waitForResponse(response => response.url().startsWith("https://www.instagram.com/graphql/query/?query_hash="))
//   ]);

//   const res = await response.json();

//   setSuccess({
//     full_name: res.data.shortcode_media.owner.full_name,
//     username: res.data.shortcode_media.owner.username,
//     profile_pic_url: res.data.shortcode_media.owner.profile_pic_url,
//     video_duration: res.data.shortcode_media.video_duration,
//     thumbnail: res.data.shortcode_media.thumbnail_src,
//     video_url: res.data.shortcode_media.video_url,
//     total_views: res.data.shortcode_media.video_view_count
//   });
// }

// async function scrap(platform = 'facebook', url, headless = true) {
//   const browser = await puppeteer.launch({ headless: headless });

//   const page = await browser.newPage();

//   await page.setViewport({ width: 1200, height: 720 });

//   if (platform == 'facebook') {
//     /* FACEBOOK BLOCK */

//     if (!url.includes('https://www.facebook.com/')) {
//       setError('Invalid facebook url. e.g: https://www.facebook.com/watch?v=567231208557797')
//     }

//     else await scrapFacebook(page, url)

//   } else if (platform == 'instagram') {
//     /* INSTAGRAM BLOCK */

//     if (!url.includes('https://www.instagram.com/')) {
//       setError('Invalid instagram url. e.g: https://www.instagram.com/reel/CmPT92rDfP4/')
//     }

//     else await scrapInstagram(page, url)
//   }else setError('This plaform is not yet supported. ( Supported platforms are : facebook and instagram )')

//   await browser.close();
// }

// app.post('/scrap', async function (req, res) {
//   try {
//     if (req.body?.platform && req.body?.url) {
//       await scrap(req.body.platform, req.body.url, true, res)

//       console.log(`scrapped the url : ${req.body.url} ( ${success.bool ? 'success' : 'error'} )`)
//     }
//     else {
//       setError('Both platforms ( facebook, instagram ) and url ( https://www.instagram.com/reel/CmPT92rDfP4/ or https://www.facebook.com/watch?v=567231208557797 ) are required.');
//     }

//     success.bool ? res.send(success) : res.send(error)
//   } catch (e) {
//     console.log("error", e)
//   }
// })

// app.get('/', function (req, res) {
//   res.send("Visit /scrap with POST method and Data => url = https://www.facebook.com/watch?v=567231208557797 and platform = 'facebook'")
// })